# Rotina Guiada 50+ v1.1

Projeto Android – Base funcional.
Abra no Android Studio.
